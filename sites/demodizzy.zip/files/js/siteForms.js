function checkPaymentReceipt(id) {
	if (jQuery(':radio:checked','#payment_choose').attr('class') == 'receipt') {
		var url = window.location.href;
		var win = window.open("", "_blank", "width=710,height=620,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=no");
		win.document.write("<html><head><" + "script" + ">location.href = '" + url + "do/?payment-id=" + id + "'</script></head><body></body></html>");
		location.href = '/emarket/ordersList/?' + Math.random();
		win.focus();
		return false;
	}
}

var siteForms = {
	init : function() {
		var elements_arr = jQuery('label.required input'), element;
		for (var i = 0; elements_arr.length > i; i++) {
			element = elements_arr[i];
			element.onchange = siteForms.errors.show(element, i);
		}
	},
	check : function(form, num) {
		var r = num, elements_arr = jQuery('label.required input', form);
		++r;
		for (var i = 0; elements_arr.length > i; i++) {
			if (typeof num != "undefined" && elements_arr[r] == elements_arr[i]) return false;
			if (!siteForms.errors.check(elements_arr[i], num)) return false;
		}
	},
	data : {
		save : function(form) {
			if (!form && !form.id) return false;
			var cookieData = new Array, str = "", input, inputName, elementData, value, i;
			for (i = 0; i < form.elements.length; i++) {
				input = form.elements[i];
				if (input.name) {
					inputName = input.name.replace(/([)\\])/g, "\\$1");
					switch (input.type) {
						case "password": {
							break;
						}
						case "text":
						case "textarea": {
							cookieData.push({type: 'TX', name: inputName, value: input.value});
							break;
						}
						case "checkbox":
						case "radio": {
							cookieData.push({type: 'CH', name: input.id, value: (input.checked ? 1 : 0)});
							break;
						}
						case "select-one": {
							cookieData.push({type: 'SO', name: inputName, value: input.selectedIndex});
							break;
						}
						case "select-multiple": {
							var opt_str = "", opt_len = input.options.length, o;
							for (o = 0; o < opt_len; o++) {
								var option = input.options[o];
								if (option.selected) {
									opt_str += option.value;
									if (o < (opt_len-1)) opt_str += ":";
								}
							}
							cookieData.push({type: 'SM', name: inputName, value: opt_str});
							break;
						}
					}
				}
			}
			for (i = 0; i < cookieData.length; i++) {
				elementData = cookieData[i];
				value = new String(elementData.value);
				inputName = new String(elementData.name);
				if (!inputName || !value) continue;
				str += elementData.type + "," + inputName.length + "," + inputName + "," + value.length + "," + value;
			}
			document.cookie = "frm" + form.id + "=" + escape(str.replace(/([|\\])/g, "\\$1"));
			return true;
		},
		restore : function() {
			var cookie = new String(unescape(document.cookie));
			var forms = document.getElementsByTagName('form');
			var cookieName, posStart, posEnd, form, i, elementData, type, length, inputName, value;
			for (i = 0; i < forms.length; i++) {
				if (forms[i].id) {
					cookieName = "frm" + forms[i].id + "=";
					if ((posStart = cookie.indexOf(cookieName)) != -1) form = forms[i];
				}
			}
			if (!cookieName || !form) return false;
			if ((posEnd = cookie.indexOf(";", posStart)) == -1) posEnd = cookie.length;
			var data = cookie.substring(posStart + cookieName.length, posEnd);
			var pos = 0, cookieData = new Array;
			while (pos < data.length) {
				type = data.substring(pos, pos + 2);
				pos += 3;
				length = parseInt(data.substring(pos, data.indexOf(",", pos)));
				pos = data.indexOf(",", pos) + 1;
				inputName = data.substring(pos, pos + length);
				pos += length + 1;
				length = parseInt(data.substring(pos, data.indexOf(",", pos)));
				if (length == 0) {
					pos += 2;
					continue;
				}
				else pos = data.indexOf(",", pos) + 1;
				value = data.substring(pos, pos + length);
				pos += length;
				cookieData.push({type: type, name: inputName, value: value});
			}
			for (i = 0; i < cookieData.length; i++) {
				elementData = cookieData[i];
				if (elementData.type && elementData.name) {
					switch(elementData.type) {
						case "PW": {
							break;
						}
						case "TX": {
							form.elements[elementData.name].value = elementData.value;
							break;
						}
						case "CH": {
							document.getElementById(elementData.name).checked = (elementData.value == 1) ? true : false;
							break;
						}
						case "SO": {
							form.elements[elementData.name].selectedIndex = elementData.value;
							break;
						}
						case "SM": {
							var options = form.elements[elementData.name].options;
							var opt_arr = elementData.value.split(":"), op, o;
							for (op = 0; op < options.length; op++) 
								for (o = 0; o < opt_arr.length; o++) 
									if (opt_arr[o] && (options[op].value == opt_arr[o])) 
										options[op].selected = true;
							break;
						}
					}
				}
			}
		}
	},
	errors : {
		show : function(element, num) {
			return (function(){siteForms.check(element.form, num);});
		},
		check : function(element, num) {
			var _err, empty_err = "Поле обязательно для заполнения.";
			//var callback = function(transport){return (siteForms.errors.write(transport.responseText, element));};
			switch (element.name) {
				case "login": {
					switch (element.value.length) {
						case 0: _err = empty_err;
						break;
						case 1:
						case 2:
							_err = "Слишком короткий логин. Логин должен состоять не менее, чем из 3х символов.";
						break;
						default: {
							if (element.value.length > 40) _err = "Слишком большой логин. Логин должен состоять не более, чем из 40 символов.";
							if (typeof num != 'undefined') ;//checkUserLogin callback
						}
						break;
					}
				}
				break;
				case "password": {
					switch (element.value.length) {
						case 0: _err = empty_err;
						break;
						case 1:
						case 2:
							_err = "Слишком короткий пароль. Пароль должен состоять не менее, чем из 3х символов.";
						break;
						default: {
							if (element.form.elements['login'].value == element.value) {
								_err = "Пароль не должен совпадать с логином.";
							}
						}
						break;
					}
				}
				break;
				case "password_confirm": {
					if (element.value.length == 0) _err = empty_err;
					else if (element.form.elements['password'].value !== element.value) {
						_err = "Пароли должны совпадать.";
					}
				}
				break;
				case "email": {
					if (element.value.length == 0) _err = empty_err;
					else if (!element.value.match(/.+@.+\..+/)) _err = "Некорректный e-mail.";
					else if (typeof num != 'undefined') ;//checkUserEmail callback
				}
				break;
				default:
					if (element.value.length == 0) _err = empty_err;
					if (element.name.match(/^.*e.*mail.*$/)) if (!element.value.match(/.+@.+\..+/)) _err = "Некорректный e-mail.";
				break;
			}
			return (siteForms.errors.write(_err, element));
		},
		write : function(_err, element) {
			var cont = element.parentNode.parentNode;
			var old_err = jQuery('div.formErr', cont).remove();
			if (_err) {
				var err_block = document.createElement('div');
				err_block.className = "formErr";
				err_block.innerHTML = _err;
				cont.style.backgroundColor = '#ff9999';
				cont.appendChild(err_block);
				if (element.name == "password_confirm") element.value = "";
				element.focus();
				return false;
			}
			else {
				cont.style.backgroundColor = '';
				return true;
			}
		}
	}
};

jQuery(document).ready(function() {
	siteForms.data.restore();
	siteForms.init();
});